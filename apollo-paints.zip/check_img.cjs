const fs = require('fs');
['src/assets/PEB.jpg', 'src/assets/agriculture-implements.jpg', 'src/assets/almirah.jpg', 'src/assets/motors.jpg'].forEach(file => {
  const buffer = fs.readFileSync(file);
  console.log(file, buffer.slice(0, 10));
});
