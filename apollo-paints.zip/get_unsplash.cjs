const https = require('https');

function search(query) {
  return new Promise((resolve, reject) => {
    https.get(`https://unsplash.com/napi/search/photos?query=${encodeURIComponent(query)}&per_page=3`, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json.results.map(r => r.urls.raw + '&auto=format&fit=crop&w=800&q=80'));
        } catch (e) {
          resolve([]);
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log('Pump:', await search('water pump'));
  console.log('Motor:', await search('electric motor'));
  console.log('Almirah:', await search('steel wardrobe'));
  console.log('Locker:', await search('steel locker'));
}
run();
