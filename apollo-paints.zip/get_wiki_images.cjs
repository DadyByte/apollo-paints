const https = require('https');

function searchWiki(query) {
  return new Promise((resolve, reject) => {
    const url = `https://en.wikipedia.org/w/api.php?action=query&generator=search&gsrsearch=${encodeURIComponent(query)}&prop=pageimages&format=json&pithumbsize=800`;
    https.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          const pages = json.query.pages;
          for (const key in pages) {
            if (pages[key].thumbnail) {
              console.log(query, '->', pages[key].thumbnail.source);
            }
          }
          resolve();
        } catch (e) {
          resolve();
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  await searchWiki('file cabinet');
  await searchWiki('locker room');
}
run();
