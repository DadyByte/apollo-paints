const https = require('https');

function search(query) {
  return new Promise((resolve, reject) => {
    https.get(`https://unsplash.com/napi/search/photos?query=${query}&per_page=1`, {
      headers: { 'User-Agent': 'Mozilla/5.0' }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json.results[0].urls.raw + '&auto=format&fit=crop&w=800&q=80');
        } catch (e) {
          resolve('error');
        }
      });
    }).on('error', reject);
  });
}

async function run() {
  console.log('Tractor:', await search('tractor'));
  console.log('Factory:', await search('steel factory'));
  console.log('Cabinet:', await search('metal cabinet'));
  console.log('Appliance:', await search('home appliance'));
  console.log('Pump:', await search('industrial pump'));
  console.log('Furniture:', await search('wooden furniture'));
}
run();
